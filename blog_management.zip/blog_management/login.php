<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $conn =new  mysqli('localhost', 'root', '', 'blog');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT  id,name, password, role FROM users WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $name, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            // Set session variables
            $_SESSION['user_id'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['role'] = $role;

            // Redirect based on role
            if ($role === 'user') {
                header("Location: user_dash.php");
            } elseif ($role === 'author') {
                header("Location: author.php");
            } elseif ($role === 'admin') {
                header("Location: admin.php");
            }
            exit;
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "No user found with this email.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
            background: #f4f4f9;
        }

        /* Split-Screen Container */
        .container {
            display: flex;
            width: 80%;
            height:60vh;
            max-width: 900px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            overflow: hidden;
        }

        /* Left Section */
        .left-panel {
            flex: 1;
            background: #2c3e50;/*#2cc49c; /* Gradient Background */
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 50px;
        }

        .left-panel h1 {
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .left-panel p {
            font-size: 1rem;
            margin-bottom: 30px;
        }

        .left-panel button {
            padding: 10px 20px;
            background: white;
            color: #2cc49c;
            border: none;
            border-radius: 20px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        .left-panel button:hover {
            background: #2cc49c;
            color: white;
            border: 2px solid white;
        }

        /* Right Section */
        .right-panel {
            flex: 1.5;
            background: white;
            padding: 60px;
        }

        .right-panel h2 {
            text-align: center;
            font-size: 1.5rem;
            margin-bottom: 30px;
            color: #333;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        form input {
            padding: 12px 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
        }

        form input:focus {
            outline: none;
            border: 1px solid #2cc49c;
            box-shadow: 0 0 5px rgba(44, 196, 156, 0.5);
        }

        form button {
            padding: 12px 20px;
            background: #2c3e50;/*#2cc49c;*/
            color: white;
            font-size: 1rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        form button:hover {
            background: #249d86;
        }

        .error {
            color: red;
            text-align: center;
            margin: 10px 0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                width: 90%;
                height:auto;
            }

            .left-panel, .right-panel {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Left Section -->
        <div class="left-panel">
            <h1>New Here?</h1>
            <p>Create an account to join our community!</p>
            <button onclick="window.location.href='register.php'">Sign Up</button>
        </div>

        <!-- Right Section -->
        <div class="right-panel">
            <h2>Login</h2>
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
            <form method="post" action="login.php">
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
        </div>
    </div>
</body>
</html>

